# Online Doctor Android

Android app for the Online Doctor project.

Backend is preconfigured to:

`https://online-doctor-m7hg.onrender.com`

## Features
- Pashto, Dari, English, Urdu UI
- AI health chat through the Render backend
- Patient profile fields
- Voice input/output where supported by WebView
- Medicine label photo upload/scan
- Local chat history
- Emergency/red-flag guidance

## Build in Android Studio
Open this folder in Android Studio, allow Gradle Sync to complete, then use **Build > Build APK(s)**.

Expected debug APK path:
`app/build/outputs/apk/debug/app-debug.apk`

## Security
The OpenAI API key is NOT stored in this Android project. It stays on Render as `OPENAI_API_KEY`.


## v1.1 production preparation
- versionCode 2 / versionName 1.1.0
- launcher icon added
- safer camera/microphone permission handling
- production backend URL locked to HTTPS Render endpoint
- clearer network/server error message
- GitHub Actions builds a test APK automatically
- signed release APK + Play Store AAB are built when signing secrets are configured

Required GitHub Actions secrets for signed release:
- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`
